public interface AccountType {
    double AddInterest(double balance);
}
